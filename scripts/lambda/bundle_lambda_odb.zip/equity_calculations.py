import geopandas as gpd
import pandas as pd
import numpy as np
from urllib.parse import unquote_plus
from io import StringIO
import json
import shapely
import boto3
import io
import sys
import pickle
import os
import datetime

data_bucket = os.environ["DATA_BUCKET"]
file_bucket_region = os.environ["FILE_BUCKET_REGION"]
data_bucket_region = os.environ["DATA_BUCKET_REGION"]
############### Helper Functions ####################
def write_update_json(system_key, bucket=data_bucket, update_json=None):
    # Function to create an update JSON with update, warning, and error messages
    # to relay back to frontend:
    # INPUT:
    #   system_key: system file key on S3
    #   bucket: bucket to write to. This should be set by env vars at top of
    #        script
    #   new_json: None if creating update json for the first time. Or value of
    #       new_json if you want to update the value of this json

    # Create S3 key from file_key
    update_key = "update-data/" + system_key + ".json"
    s3 = boto3.client("s3", region_name=file_bucket_region)

    if update_json is None:
        json_u = {
            "updates": {"started_processing": True},
            "warnings": {},
            "errors": {},
        }
    else:
        json_u = update_json

    s3.put_object(
        Body=(bytes(json.dumps(json_u).encode("UTF-8"))),
        Bucket=bucket,
        Key=update_key,
    )


def read_in_update_json(system_key, bucket=data_bucket):
    # Function to readin update JSON with update, warning, and error messages
    # INPUT:
    #   system_key: system file key on S3

    update_key = "update-data/" + system_key + ".json"
    s3 = boto3.client("s3", region_name=file_bucket_region)
    r = s3.get_object(Bucket=bucket, Key=update_key)["Body"].read().decode()
    result = json.loads(r)
    return result


def add_to_update_json(
    system_key, key, value, bucket=data_bucket, msg_type="updates",
):
    # Helper function to add to update JSON with updates, warnings and errors
    # messages.
    # INPUT
    #   system_key = system_key on S3
    #   msg_type, must be one of "updates", "warnings", or "errors" corresponding
    #       structure of JSON
    #   key: name of key as it will appear in JSON
    #   value: name of value as it will appear in JSON

    # Read in update_json
    old_json = read_in_update_json(system_key)

    # Append key and value to specified message type
    m = old_json[msg_type]
    m.update({key: value})
    old_json[msg_type] = m
    new_json = old_json

    # Reupload to S3
    write_update_json(system_key, update_json=new_json)


def select_geojson_as_gdf(bucket, key):
    # Function to read in geojson from s3 as a gdf
    # Input:
    #     bucket: s3 bucket, string
    #     key: full s3 key including prefixes, string
    # Output:
    #     gdf: a gdf
    s3 = boto3.client("s3", region_name=file_bucket_region)
    obj = s3.get_object(Bucket=bucket, Key=key)
    json_g = json.loads(obj["Body"].read().decode("utf-8"))
    gdf = gpd.GeoDataFrame.from_features(json_g["features"])
    gdf = gdf[["geometry"]]
    return gdf


def s3_select_csv_as_gdf(s3_bucket, s3_key):
    # Function to read in csv from s3 as a gdf using S3
    # select to only read in lat/lon columns
    # Input:
    #     bucket: s3 bucket, string
    #     key: full s3 key including prefixes, string
    # Output:
    #     gdf: a gdf
    s3 = boto3.client("s3", region_name=file_bucket_region)
    try:
        r = s3.select_object_content(
            Bucket=s3_bucket,
            Key=s3_key,
            ExpressionType="SQL",
            Expression="select s.longitude,s.latitude from S3Object s where s.latitude like '___%' ",
            RequestProgress={"Enabled": True},
            InputSerialization={
                "CSV": {
                    "FileHeaderInfo": "Use",
                    "AllowQuotedRecordDelimiter": True,
                }
            },
            OutputSerialization={"CSV": {}},
        )
    except:
        try:
            r = s3.select_object_content(
                Bucket=s3_bucket,
                Key=s3_key,
                ExpressionType="SQL",
                Expression="select s.lon,s.lat from S3Object s where s.lat like '___%' ",
                RequestProgress={"Enabled": True},
                InputSerialization={
                    "CSV": {
                        "FileHeaderInfo": "Use",
                        "AllowQuotedRecordDelimiter": True,
                    }
                },
                OutputSerialization={"CSV": {}},
            )
        except:
            try:
                r = s3.select_object_content(
                    Bucket=s3_bucket,
                    Key=s3_key,
                    ExpressionType="SQL",
                    Expression="select s.long,s.lat from S3Object s where s.lat like '___%' ",
                    RequestProgress={"Enabled": True},
                    InputSerialization={
                        "CSV": {
                            "FileHeaderInfo": "Use",
                            "AllowQuotedRecordDelimiter": True,
                        }
                    },
                    OutputSerialization={"CSV": {}},
                )
            except:
                try:
                    r = s3.select_object_content(
                        Bucket=s3_bucket,
                        Key=s3_key,
                        ExpressionType="SQL",
                        Expression="select s.longitude,s.latitud from S3Object s where s.latitud like '___%' ",
                        RequestProgress={"Enabled": True},
                        InputSerialization={
                            "CSV": {
                                "FileHeaderInfo": "Use",
                                "AllowQuotedRecordDelimiter": True,
                            }
                        },
                        OutputSerialization={"CSV": {}},
                    )
                except:
                    try:
                        r = s3.select_object_content(
                            Bucket=s3_bucket,
                            Key=s3_key,
                            ExpressionType="SQL",
                            Expression="select s.longitud,s.latitude from S3Object s where s.latitude like '___%' ",
                            RequestProgress={"Enabled": True},
                            InputSerialization={
                                "CSV": {
                                    "FileHeaderInfo": "Use",
                                    "AllowQuotedRecordDelimiter": True,
                                }
                            },
                            OutputSerialization={"CSV": {}},
                        )
                    except:
                        r = 0
                        print("lat/lon columns not in given formats")
                        raise NameError("lat/lon columns not in given formats")
                        sys.exit()
    finally:
        # build an iterator and set up loop to read in df
        r_iter = iter(r["Payload"])
        counter = 0
        t = "longitude,latitude\n"
        # start = 5000
        # end = start+50

        # iterate over events in eventsteram to build csv string (t)
        for event in r_iter:
            if "Records" in event:
                counter += 1
                records = event["Records"]["Payload"].decode("utf-8")
                t += records

        # Remove pesky carriage return characters that are in some CSVs out in the wild;
        # leaving it in causes Pandas to read in all NA values.
        t = t.replace("\r", "")

        # convert csv string to df
        df = pd.read_csv(io.StringIO(t))
        df = df[df.latitude.notnull()]

        # converting df to gdf
        geometry = [
            shapely.geometry.Point(xy) for xy in zip(df.longitude, df.latitude)
        ]
        gdf = gpd.GeoDataFrame(
            df.drop(["latitude", "longitude"], axis=1),
            crs=4326,
            geometry=geometry,
        )
        del df, t
        return gdf


def get_place_geoid(df, place_df):
    # Function to get the Census place GEOID of a gdf with lat/lons
    # select to only read in lat/lon columns
    # Input:
    #     df: input gdf of lat/lon points
    #     place_df: gdf that lists polygons of all Census places
    # Output:
    #     place: string, the GEOID of the most frequently ocurring
    #            Census place in sample of df

    nrow_data = df.shape[0]
    if nrow_data > 50:
        # 5% sample of points to reduce spatial join processing time
        npnts = int(round(0.05 * df.shape[0]))
    else:
        npnts = nrow_data

    dfs = df.sample(npnts)
    x = (
        gpd.sjoin(dfs, place_df, op="within", how="left")
        .groupby("place_geoid")["place_geoid"]
        .count()
        .sort_values(ascending=False)
    )
    # return most frequent city in sample of data, may want to change in the future
    place = x.index[0]
    if len(x) == 1:
        return place
    else:
        print(
            "There were multiple census places in the data, returning the most common one"
        )
        return place


def read_in_pkl_from_s3_as_gdf(bucket, key):
    # Function to read in a pickled python file from s3 as a gdf
    #     bucket: s3 bucket, string
    #     key: full s3 key including prefixes, string
    # Output:
    #     data: the pickled data

    s3 = boto3.client("s3", region_name=data_bucket_region)
    response = s3.get_object(Bucket=bucket, Key=key)
    data = pickle.loads(response["Body"].read())
    return data


def read_in_csv_from_s3_as_gdf(
    bucket, key, system_key=system_key, lon_column="lon", lat_column="lat"
):
    # Function to read in a csv from s3 as a gdf. Assumes csv has columns
    # named 'lat' and 'lon'.
    #     bucket: s3 bucket, string
    #     key: full s3 key including prefixes of input-data CSV, string
    # Output:
    #     data: the pickled data
    s3 = boto3.client("s3", region_name=data_bucket_region)
    obj = s3.get_object(Bucket=bucket, Key=key)
    df = pd.read_csv(io.BytesIO(obj["Body"].read()))

    # Rename lat/lon columns to lon and lat so we can use fixed names with zip statement below
    df.rename(columns={lon_column: "lon", lat_column: "lat"})

    # Get number of rows in raw data to report number of rows filtered out
    nrow_raw = df.shape[0]

    # Filter out null rows and write how many rows were filtered out to update
    # json
    df = df[df.lat.notnull()]

    nrow_filtered = df.shape[0]
    add_to_update_json(
        system_key, "null_rows_filtered", str(nrow_filtered - nrow_raw)
    )

    # converting df to gdf
    geometry = [shapely.geometry.Point(xy) for xy in zip(df.lon, df.lat)]
    gdf = gpd.GeoDataFrame(
        df.drop(["lon", "lat"], axis=1), crs=4326, geometry=geometry
    )
    del df
    return gdf
    # return(df)


def read_in_tracts_by_place_from_s3(
    tractbyplace_bucket, place_geoid, year="2017"
):
    s3 = boto3.client("s3", region_name=data_bucket_region)
    # response = s3.get_object(Bucket = tractbyplace_bucket, Key =
    #                         "tracts_by_place_pickles/" + str(place_geoid) +
    #                         ".pkl")
    response = s3.get_object(
        Bucket=tractbyplace_bucket,
        Key="reference-data/"
        + year
        + "/tracts_by_place/"
        + str(place_geoid)
        + ".pkl",
    )
    data = pickle.loads(response["Body"].read())
    # data.reset_index(inplace=True)
    return data


def place_df_in_s3(df, bucket, key):
    # Function to place a df in s3 as a csv
    #     df: a df
    #     bucket: s3 bucket, string
    #     key: full s3 key including prefixes, string
    # Output:
    #     None
    csv_buffer = io.StringIO()
    df.to_csv(csv_buffer, index=False)
    s3 = boto3.client("s3", region_name=file_bucket_region)
    s3.put_object(Body=csv_buffer.getvalue(), Bucket=bucket, Key=key)


def place_df_as_json_in_s3(df, bucket, key):
    # Function to place a df in s3 as a csv
    #     dict: a python dict (ie a json file)
    #     bucket: s3 bucket, string
    #     key: full s3 key including prefixes, string
    # Output:
    #     None
    json_data = df.to_json(orient="records", default_handler=str)
    s3 = boto3.client("s3", region_name=file_bucket_region)
    s3.put_object(
        Body=(bytes(json_data.encode("UTF-8"))), Bucket=bucket, Key=key
    )


def create_city_data_values_dicts(
    df_data, colname, censusvar, numsamp, list, data_reshaped
):
    # specific helper function to create stats_df datafrme, only works with df_data = temp.
    # Adds city_value, data_value, and data_value_sd columns using weighted aggregation of
    # census variables in temp df
    #     df_data: df to compute statistics on, need to be = temp
    #     colname: name of column to be added
    #     censusvar: Name of census var on which calculation is done
    #     numsamp: NUmber of samples to perform for sd calculation
    #     list: list_of_dicts to append to
    #     data_reshaped: reshaped data for use in normal sampling
    # Output:
    #    None, but appends the created dictionary to list_of_dicts (which starts out as an empty list)

    cdp_value = df_data.apply(
        lambda row: row["pop_prop"] * row[censusvar], axis=1
    ).sum()
    data_value = df_data.apply(
        lambda row: row["data_prop"] * row[censusvar], axis=1
    ).sum()

    moe_var = censusvar.replace("PE", "PM").replace("E", "M")
    data_value_sd = np.std(
        np.nansum(
            data_reshaped
            * (generate_norm_samps(df_data, numsamp, censusvar, moe_var)),
            axis=0,
        )
    )

    vals = {
        "census_var": colname,
        "data_value": data_value,
        "city_value": cdp_value,
        "diff_data_city": data_value - cdp_value,
        "data_value_sd": data_value_sd,
    }
    list.append(vals)


# function for normal sampling, used for normal sampling of data implied stats
def generate_norm_samps(df, npoints, variable, moe):
    mu, sigma = df[variable].values, (df[moe].values) / 1.645
    samps = np.random.normal(mu, sigma, [npoints, mu.shape[0]]).transpose()
    samps[samps < 0] = 0
    return samps


# TODO: Remove harcoding of names, years and vars, allow configurable year, which
# TODO: automatically pulls relevant names->var translation list and pulls
# TODO: data from s3
# colnames are the human readable names of the census variables corresponding to
# the names in censusvars.
colnames = [
    "pct_bach",
    "pct_pov",
    "hh_med_inc",
    "pct_unemp",
    "pct_white",
    "pct_black",
    "pct_anai",
    "pct_asian",
    "pct_nh_pi",
    "pct_other_race",
    "pct_two_race",
    "pct_hisp",
]
censusvars = [
    "DP02_0067PE",
    "DP03_0119PE",
    "DP03_0062E",
    "DP03_0009PE",
    "DP05_0077PE",
    "DP05_0078PE",
    "DP05_0079PE",
    "DP05_0080PE",
    "DP05_0081PE",
    "DP05_0082PE",
    "DP05_0083PE",
    "DP05_0071PE",
]


year = "2017"


def handler(event, context):

    # * Below args for testing script
    # file_key = "input-data/WirelessHotspotsfromDCGovernment-1597674757.csv"
    # trigger_bucket = "ui-equity-tool-stg"
    # request_id = 10
    # file_bucket_region = "us-east-1"
    # data_bucket_region = "us-east-1"
    # data_bucket = "ui-equity-tool-stg"

    # spcl chars like `(` and `)` are URL encoded weirdly by the S3 event object
    # causing s3 key not found errors. We fix this by using unquote_plus
    file_key = unquote_plus(event["Records"][0]["s3"]["object"]["key"])
    trigger_bucket = event["Records"][0]["s3"]["bucket"]["name"]
    request_id = event["Records"][0]["responseElements"]["x-amz-request-id"]
    print(file_key)

    # Get system key and form key
    # We conservatively replace first and last occurrence in case user
    # has "input-data" or ".csv" in the file name. Note this should never
    # happen as Dave's API renames files in a controlled manner.
    # Replace first occurrence of input-data/ with form-data/
    s = file_key.replace("input-data/", "", 1)
    system_key = "".join(s.rsplit(".csv", 1))

    # Get form data and extract lat/lon names, weights and filters
    form_key = "form-data/" + system_key + ".json"

    client = boto3.client("s3")
    result = client.get_object(Bucket=trigger_bucket, Key=form_key)
    form_data = json.loads(result["Body"].read().decode())

    lat_name = form_data["lat_column"]
    lon_name = form_data["lon_column"]
    filters = form_data["filters"]
    weight_name = form_data["weights"]

    # Create update JSON which we will be writing, updates, warnings, and errors
    # to
    write_update_json(system_key)
    print("BLARGHHH")

    ######################################
    ########## Reading in Data ###########
    ######################################

    # Read in csv/geojson based on file ending and fix badly formatted geojsons
    # (offical geojson spec is CRS = 4326, but GeoJSONS in the wild may not have CRS attached)
    if file_key.endswith("csv"):
        # ! Old readin function that used S3 select, but often failed
        # point_data = s3_select_csv_as_gdf(trigger_bucket, file_key)
        # * New readin function that reads in CSV's assuming lat/lon columns
        point_data = read_in_csv_from_s3_as_gdf(
            trigger_bucket,
            file_key,
            system_key=system_key,
            lon_column=lon_name,
            lat_column=lat_name,
        )

    if file_key.endswith("geojson"):
        point_data = select_geojson_as_gdf(trigger_bucket, file_key)
        if point_data.crs == None:
            point_data.crs = 4326

    # Read in gdf of Census places with pop greater than 50k
    place_data = read_in_pkl_from_s3_as_gdf(
        data_bucket,
        "reference-data/"
        + year
        + "/big_places_us_manual_tract_join_1p_cutoff.pkl",
    )

    #############################################
    ########## Spatially joining data ###########
    #############################################

    # Find the Census place that the data is from
    try:
        place_geoid = get_place_geoid(point_data, place_data)
    # if this returns Valueerror, most likely no points in data are within
    # big_places_shapefiles (ie data isn't in a big US city).
    # Before erroring out, lets make sure data wasn't badly coded. One common
    # data entry error is that lon/lat columns are flipped. So lets unflip and try again
    except ValueError:
        from shapely.geometry import Point

        point_data["coordinates"] = list(
            zip(point_data.geometry.y, point_data.geometry.x)
        )
        point_data["coordinates"] = point_data["coordinates"].apply(Point)
        point_data = point_data.drop("geometry", axis=1)
        point_data = point_data.rename(
            index=str, columns={"coordinates": "geometry"}
        )
        point_data = gpd.GeoDataFrame(point_data, geometry="geometry", crs=4326)
        place_geoid = get_place_geoid(point_data, place_data)

    # Filter the place_data gdf to the specific place the data is from
    place_data = place_data[place_data.place_geoid == place_geoid]

    # Read in census tracts for that place
    poly_data = read_in_tracts_by_place_from_s3(
        data_bucket, place_geoid
    )  # read in all tracts in city
    tot_points = point_data.shape[0]

    # spatially joining points to tracts in chunks of 800k points to avoid
    # exceeding RAM limits of lambda
    temp = pd.Series(data=0, index=poly_data["tract_geoid"].unique())
    loop_cutoff = 80000
    while point_data.shape[0] > 0:
        temp1 = (
            gpd.sjoin(
                point_data[:loop_cutoff], poly_data, op="within", how="left"
            )
            .groupby("tract_geoid")["tract_geoid"]
            .count()
            .sort_values(ascending=False)
        )
        temp = temp.add(temp1, fill_value=0).sort_values(ascending=False)
        point_data.drop(point_data.index[:loop_cutoff], inplace=True)

    temp = pd.DataFrame({"tract_geoid": temp.index, "counts": temp.values})

    temp = pd.merge(
        temp, poly_data, left_on="tract_geoid", right_on="tract_geoid"
    )

    #################################################################
    ########## Calculate geographic bias and significance ###########
    #################################################################
    # TODO: DP02_0086E = population, need to dynamically pull from census var
    # TODO: list or csv, not hardcode
    total_pop = temp["DP02_0086E"].sum()
    tot_points_joined = temp["counts"].sum()
    # data_prop = proportion of datapoints within the tract, = # of datapoints
    # within tract (ie counts) / total number of points in data (ie tot_points_joined)
    temp["data_prop"] = temp.apply(
        lambda row: row["counts"] / tot_points_joined, axis=1
    )
    # pop_prop = proportion of popoulation within the tract, = pop of tract /
    # total number of population in the city
    temp["pop_prop"] = temp.apply(
        lambda row: row["DP02_0086E"] / total_pop, axis=1
    )
    # pop_prop = difference between data_prop and pop_prop
    temp["diff_prop"] = temp.apply(
        lambda row: row["data_prop"] - row["pop_prop"], axis=1
    )

    temp["upper"] = temp["pop_prop"] + 3 * temp["pop_prop_sd"]
    temp["lower"] = temp["pop_prop"] - 3 * temp["pop_prop_sd"]
    temp["sig_diff"] = np.where(
        (temp["data_prop"] <= temp["lower"])
        | (temp["data_prop"] >= temp["upper"]),
        "TRUE",
        "FALSE",
    )
    temp = temp.drop(["upper", "lower"], axis=1)

    #############################################
    ########## Writing out outputs  #############
    #############################################
    # get filenames, which we later append _log, _stats, _map to for output names
    output_filename = os.path.basename(os.path.normpath(file_key))
    output_filename = output_filename.replace(".csv", "").replace(
        ".geojson", ""
    )

    ######## place mapdata_df(ie temp) in output/mapdata/ folder #####

    # TODO: Put census variable columns back in to display on map tooltip
    # Filter out census variable columns and GEOID/index columns bc its not used
    # in map and keeps file small
    cols = [
        s
        for s in temp.columns
        if not s.startswith("DP") and s not in ["GEOID", "index"]
    ]

    map_data_fname = "output/map_data/" + output_filename + "_mapdata" + ".json"
    place_df_as_json_in_s3(
        df=temp[cols], bucket=trigger_bucket, key=map_data_fname
    )

    ########## create and place stats_df in output/stats_data/ folder ########

    # set up variables for creating stats df and normal sampling within loop
    list_of_dicts = []
    numsamp = 10000
    data_prop_reshaped = temp["data_prop"].values.reshape(
        temp["data_prop"].values.shape[0], 1
    )
    for names, var in zip(colnames, censusvars):
        # Appends a dict, to the list of dicts
        # Each dict corresponds to a census variable of interest
        create_city_data_values_dicts(
            temp, names, var, numsamp, list_of_dicts, data_prop_reshaped
        )
    # Creating dataframe from list of dicts
    stats_df = pd.DataFrame(list_of_dicts)

    # Calculate pct_smaller_races using dummy smaller_races column
    # Note pct_smaller_races = pct_anai + pct_nhpi + pct_other_race +
    # prt_two_race
    stats_df["smaller_races"] = np.where(
        stats_df["census_var"].isin(
            ["pct_anai", "pct_nh_pi", "pct_other_race", "pct_two_race"]
        ),
        1,
        0,
    )

    sml_races = (
        stats_df.groupby(["smaller_races"])[
            ["data_value", "city_value", "diff_data_city"]
        ]
        .sum()
        .loc[[1]]
    )
    sml_races["census_var"] = "pct_smaller_races"

    # Append pct_smaller_races to stats_df
    stats_df = stats_df.append(sml_races, sort=True)
    del stats_df["smaller_races"]

    # Compute data_value_sd for pct_smaller_races. This column is a sum of three other
    # columns, so we perform normal sampling for all 3 columns, sum then get std.
    # Note this replaces only one cell in the df which was NaN before.
    pct_smaller_races_ind = [
        colnames.index("pct_anai"),
        colnames.index("pct_nh_pi"),
        colnames.index("pct_other_race"),
        colnames.index("pct_two_race"),
    ]

    smllr_races_e = [censusvars[i] for i in pct_smaller_races_ind]
    smllr_races_m = [l.replace("PE", "PM") for l in smllr_races_e]
    stats_df.loc[
        (stats_df.census_var == "pct_smaller_races"), "data_value_sd"
    ] = np.std(
        (
            data_prop_reshaped
            * (
                generate_norm_samps(
                    temp, numsamp, smllr_races_e[0], smllr_races_m[0]
                )
            )
        )
        + (
            data_prop_reshaped
            * (
                generate_norm_samps(
                    temp, numsamp, smllr_races_e[1], smllr_races_m[1]
                )
            )
        )
        + (
            data_prop_reshaped
            * (
                generate_norm_samps(
                    temp, numsamp, smllr_races_e[2], smllr_races_m[2]
                )
            )
        )
        + (
            data_prop_reshaped
            * (
                generate_norm_samps(
                    temp, numsamp, smllr_races_e[3], smllr_races_m[3]
                )
            )
        )
    )

    # Reading in Standard errors of citywide statistics (precomputed for each city to save time)
    # Some data munging done to set up join
    cdp_sd_df = read_in_pkl_from_s3_as_gdf(
        data_bucket,
        "reference-data/"
        + year
        + "/places_vars_sds/"
        + str(place_geoid)
        + ".pkl",
    )

    # left joining stats_df to standard errors df.
    stats_df = stats_df.merge(cdp_sd_df, on=["census_var"], how="left")

    # writing out stats_df
    stats_data_fname = (
        "output/stats_data/" + output_filename + "_stats" + ".json"
    )
    place_df_as_json_in_s3(
        df=stats_df, bucket=trigger_bucket, key=stats_data_fname
    )

    ############## create and place logdata df in output/logs/ folder #########
    missed_pts_pct = (tot_points - tot_points_joined) / tot_points
    cdp_name = (
        "_".join(place_data.NAMELSAD.iloc[0].split()).lower().replace(",", "")
    )
    logdata = pd.DataFrame(
        {
            "missed_pts_pct": missed_pts_pct,
            "num_datapoints": tot_points,
            "s3_input_bucket": trigger_bucket,
            "s3_input_key": file_key,
            "s3_data_bucket": data_bucket,
            "request_id": request_id,
            "cdp_name": cdp_name,
            "place_geoid": place_geoid,
        },
        index={1},
    )

    log_data_fname = "output/log_data/" + output_filename + "_logdata" + ".json"
    place_df_as_json_in_s3(
        df=logdata, bucket=trigger_bucket, key=log_data_fname
    )

    # Print statement for debugging lambda function in Cloudwatch logs
    print(
        "Finished request - "
        + cdp_name
        + "; "
        + str(tot_points)
        + " points geocoded "
        + "; "
        + str(request_id)
        + "; "
        + str(missed_pts_pct)
        + "%"
        + " missed"
    )

    # Have Lambda function return some dummy data to help debugging effort. In
    # the future may want to have frontend open a websocket connection when
    # uploading files and the lambda function eventually returns file pointers
    # to final output files.
    data = {
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "map_data": map_data_fname,
        "stats_data": stats_data_fname,
        "log_data": log_data_fname,
        "trigger_bucket": trigger_bucket,
        "ref-data-year": year,
    }

    return {
        "statusCode": 200,
        "body": json.dumps(data),
        "headers": {"Content-Type": "application/json"},
        "json": "TRUE",
    }
